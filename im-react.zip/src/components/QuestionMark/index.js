import QuestionMark from './QuestionMark';

export default QuestionMark;
