import React, { Fragment } from 'react';
import IMSelect from 'im-react/IMSelect';

export default function IMSelectExample() {
  return (
      <Fragment>
        <IMSelect />
      </Fragment>
  );
}
