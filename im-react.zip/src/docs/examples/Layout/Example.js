import React from 'react';
import Layout from 'im-react/Layout';

export default function LayoutExample() {
  return (
      <Layout height="250px" >
          <h1>Layout Example</h1>
      </Layout>
  );
}
