import React, { Fragment } from 'react';
import IMSearch from 'im-react/IMSearch';

export default function IMIconExample() {
  return (
      <Fragment>
        <IMSearch />
      </Fragment>
  );
}
