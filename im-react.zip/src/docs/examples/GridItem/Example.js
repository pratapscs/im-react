import React from 'react';
import GridItem from 'im-react/GridItem';

export default function GridItemExample() {
  return (
      <GridItem>
          <h1>Layout Example</h1>
      </GridItem>
  );
}
