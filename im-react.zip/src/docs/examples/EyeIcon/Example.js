import React from 'react';
import EyeIcon from 'im-react/EyeIcon';

export default function EyeIconExample() {
  return <EyeIcon />;
}
