import React from 'react';
import ChatItem from 'im-react/ChatItem';

export default function ChatItemExample() {
  return (
      <ChatItem />
  );
}
