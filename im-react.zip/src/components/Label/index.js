export {default} from './Label';
