import React from 'react';
import GridContainer from 'im-react/GridContainer';

export default function GridItemExample() {
  return (
      <GridContainer bgColor="#fff">
          <h1>Layout Example</h1>
      </GridContainer>
  );
}
