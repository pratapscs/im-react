import Pane from './Pane';

export default Pane;
