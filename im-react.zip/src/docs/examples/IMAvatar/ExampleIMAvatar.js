import React from 'react';
import IMAvatar from 'im-react/IMAvatar';

/** Custom message */
export default function ExampleIMAvatar() {
  return <IMAvatar/>
}
