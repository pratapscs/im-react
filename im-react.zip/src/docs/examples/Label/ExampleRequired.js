import React from 'react';
import Label from 'im-react/Label';

/** Required label */
export default function ExampleRequired() {
  return <Label htmlFor="test" label="test" required />
}
